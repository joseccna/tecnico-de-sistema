BACKUP DATABASE [AgendaContato] TO  DISK = N'C:\DB\Agendaemnto_backup' WITH NOFORMAT, NOINIT,  NAME = N'AgendaContato-Completo Banco de Dados Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
